#!/usr/bin/env python3
"""Extract an official downloaded ZIP safely; never invent labels or patient IDs."""
import argparse
import json
import shutil
import tempfile
import zipfile
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.parse import urlparse

SOURCE_URL='https://data.mendeley.com/datasets/fxjm8fb6mw/2'

def extract(archive,destination):
    destination=Path(destination).resolve();destination.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        for item in z.infolist():
            path=(destination/item.filename).resolve()
            if not path.is_relative_to(destination):
                raise ValueError('Archive contains an unsafe path.')
            if (item.external_attr>>16)&0o170000 == 0o120000:
                raise ValueError('Archive contains a symbolic link.')
            if path.exists() and not item.is_dir():
                raise ValueError(f'Extraction would overwrite {path}. Choose an empty destination.')
        z.extractall(destination)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    choice=parser.add_mutually_exclusive_group()
    choice.add_argument('--archive',help='ZIP obtained from the official dataset page.')
    choice.add_argument('--download-url',help='Exact HTTPS ZIP link copied from the official page, if available.')
    parser.add_argument('--destination',default='data/mendeley_original')
    args=parser.parse_args()
    if not args.archive and not args.download_url:
        print('Download the original data from: '+SOURCE_URL)
        print('Then run: python dataset_setup.py --archive /path/to/official.zip --destination data/mendeley_original')
        print('RAR or other containers can be extracted with your archive application; retain original images and metadata.')
        return
    if args.download_url:
        if urlparse(args.download_url).scheme!='https':
            raise ValueError('Only HTTPS download URLs are accepted.')
        with tempfile.TemporaryDirectory() as temp:
            archive=Path(temp)/'official.zip'
            with urlopen(Request(args.download_url,headers={'User-Agent':'orientation-reproduction/1.0'}),timeout=60) as response:
                with open(archive,'wb') as f:
                    shutil.copyfileobj(response,f)
            extract(archive,args.destination)
    else:
        extract(args.archive,args.destination)
    source={'url':SOURCE_URL,'doi':'10.17632/fxjm8fb6mw.2','license':'CC BY 4.0',
            'note':'A compatible source; do not equate its file count with the manuscript working split. '
                   'Confirm original labels and patient grouping using release metadata.'}
    (Path(args.destination)/'source_record.json').write_text(json.dumps(source,indent=2))
    print('Extracted data. Inspect class folders and patient metadata before preparing the manifest.')

if __name__=='__main__':
    main()
