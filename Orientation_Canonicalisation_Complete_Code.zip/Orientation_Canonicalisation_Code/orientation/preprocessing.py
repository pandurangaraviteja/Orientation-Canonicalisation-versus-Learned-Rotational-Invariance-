"""One geometric correction, explicit OpenCV sign convention, training-only HOG."""
import cv2
import numpy as np
from PIL import Image, ImageOps
from skimage.feature import hog

def read_image(path, cfg):
    with Image.open(path) as im:
        image = np.asarray(ImageOps.exif_transpose(im).convert('L'))
    size = cfg['image_size']
    image = cv2.resize(image, (size, size), interpolation=cv2.INTER_AREA)
    clahe = cv2.createCLAHE(clipLimit=cfg['clahe_clip_limit'],
                           tileGridSize=(cfg['clahe_tile_grid'],)*2)
    return clahe.apply(image)

def rotate(image, ccw_degrees):
    if abs(ccw_degrees) < 1e-12:
        return image.copy()
    h, w = image.shape
    matrix = cv2.getRotationMatrix2D(((w-1)/2, (h-1)/2), float(ccw_degrees), 1.0)
    return cv2.warpAffine(image, matrix, (w, h), flags=cv2.INTER_LINEAR,
                          borderMode=cv2.BORDER_CONSTANT, borderValue=0)

def estimate_orientation(image, cfg):
    """Positive output denotes CCW image rotation from an upright vertical axis.

    Hough theta is the normal direction in x-right/y-down coordinates. For an
    upright vertical line theta=0 mod pi. A CCW OpenCV rotation by phi produces
    normal theta=-phi. Thus estimate=-normal_angle and correction=-estimate.
    A line determines an axis modulo 180 degrees, not directed anatomy.
    """
    edges = cv2.Canny(image, cfg['canny_low'], cfg['canny_high'])
    border = int(cfg['border_exclusion_px'])
    if border:
        edges[:border] = edges[-border:] = 0
        edges[:, :border] = edges[:, -border:] = 0
    lines = cv2.HoughLines(edges, 1, np.deg2rad(cfg['hough_step_deg']), cfg['hough_votes'])
    if lines is None:
        return 0.0, False
    for _, theta in lines[:, 0]:
        normal_angle = (np.rad2deg(float(theta)) + 90) % 180 - 90
        if abs(normal_angle) <= cfg['max_orientation_deg']:
            return -normal_angle, True
    return 0.0, False

def canonicalize(image, cfg):
    angle, detected = estimate_orientation(image, cfg)
    return rotate(image, -angle), angle, detected

def variant_images(images, variant, cfg, applied_angle=0):
    result, diagnostics = [], []
    for image in images:
        observed = rotate(image, applied_angle)
        if variant == 'canon':
            output, estimate, detected = canonicalize(observed, cfg)
        elif variant == 'raw':
            output, estimate, detected = observed, 0.0, False
        else:
            raise ValueError(f'Unknown variant {variant}')
        result.append(output)
        diagnostics.append((estimate, detected))
    return np.stack(result), diagnostics

def hog_features(images):
    return np.stack([hog(image.astype(np.float32)/255.0, orientations=9,
                        pixels_per_cell=(16, 16), cells_per_block=(2, 2),
                        block_norm='L2-Hys', feature_vector=True)
                     for image in images]).astype(np.float32)
