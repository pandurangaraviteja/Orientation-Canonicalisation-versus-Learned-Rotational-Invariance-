import copy
import random
import time
from pathlib import Path
import cv2
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset
from .preprocessing import rotate

def seed_everything(seed, threads=2):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    torch.set_num_threads(threads)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.use_deterministic_algorithms(True, warn_only=True)

class HOGMLP(nn.Module):
    def __init__(self, dim, cfg):
        super().__init__()
        a, b = cfg['mlp_hidden']
        self.layers = nn.Sequential(nn.Linear(dim, a), nn.ReLU(), nn.Dropout(cfg['dropout']),
                                    nn.Linear(a, b), nn.ReLU(), nn.Dropout(cfg['dropout']),
                                    nn.Linear(b, 3))
    def forward(self, x):
        return self.layers(x)

class CompactCNN(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        blocks, cin = [], 1
        for cout in cfg['cnn_channels']:
            blocks.extend([nn.Conv2d(cin, cout, 3, padding=1), nn.BatchNorm2d(cout),
                           nn.ReLU(), nn.MaxPool2d(2)])
            cin = cout
        self.features = nn.Sequential(*blocks)
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.head = nn.Sequential(nn.Dropout(cfg['dropout']), nn.Linear(cin, 3))
    def forward(self, x):
        return self.head(self.pool(self.features(x)).flatten(1))

class Arrays(Dataset):
    def __init__(self, x, y, cfg, augment=False):
        self.x, self.y, self.cfg, self.augment = x, y, cfg, augment
    def __len__(self):
        return len(self.x)
    def __getitem__(self, index):
        a = self.x[index].copy()
        if a.ndim == 2:
            if self.augment:
                d = self.cfg['augment_rotation_deg']
                a = rotate(a, random.uniform(-d, d))
                if random.random() < self.cfg['augment_horizontal_flip_probability']:
                    a = np.fliplr(a)
                if random.random() < self.cfg['augment_vertical_flip_probability']:
                    a = np.flipud(a)
            a = a[None].astype(np.float32)/255.0
        return torch.from_numpy(np.ascontiguousarray(a, dtype=np.float32)), int(self.y[index])

def train_network(model, train_x, train_y, val_x, val_y, cfg, output, device, augment=False):
    output = Path(output); output.parent.mkdir(parents=True, exist_ok=True)
    model.to(device)
    generator = torch.Generator().manual_seed(cfg['seed'])
    train = DataLoader(Arrays(train_x, train_y, cfg, augment), batch_size=cfg['batch_size'],
                       shuffle=True, generator=generator, num_workers=0)
    val = DataLoader(Arrays(val_x, val_y, cfg), batch_size=cfg['batch_size'], num_workers=0)
    counts = np.bincount(train_y, minlength=3)
    if (counts == 0).any():
        raise ValueError('Training set must contain all three classes.')
    weights = torch.tensor(len(train_y)/(3*counts), dtype=torch.float32, device=device)
    criterion = nn.CrossEntropyLoss(weight=weights)
    optimizer = torch.optim.AdamW(model.parameters(), lr=cfg['learning_rate'],
                                  weight_decay=cfg['weight_decay'])
    best, stale, history, state = float('inf'), 0, [], None
    started = time.perf_counter()
    for epoch in range(1, cfg['epochs']+1):
        model.train(); training_loss = 0.0
        for x, y in train:
            x, y = x.to(device), y.to(device)
            optimizer.zero_grad(); loss = criterion(model(x), y)
            loss.backward(); optimizer.step(); training_loss += loss.item()*len(y)
        model.eval(); losses, correct, size = 0.0, 0, 0
        with torch.no_grad():
            for x, y in val:
                x, y = x.to(device), y.to(device)
                logits = model(x)
                # Sample-wise losses give a well-defined validation selection rule.
                batch_losses = nn.functional.cross_entropy(logits, y, weight=weights, reduction='none')
                losses += batch_losses.sum().item()
                correct += (logits.argmax(1) == y).sum().item(); size += len(y)
        score = losses/size
        history.append(dict(epoch=epoch, train_loss=training_loss/len(train_y),
                            val_loss=score, val_accuracy=correct/size))
        if score < best - 1e-6:
            best, stale = score, 0
            state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        else:
            stale += 1
        if stale >= cfg['patience']:
            break
    model.load_state_dict(state); model.eval()
    torch.save({'state_dict': state, 'config': cfg,
                'model_kind': 'cnn' if isinstance(model, CompactCNN) else 'mlp',
                'input_dim': int(train_x.shape[-1]) if isinstance(model, HOGMLP) else None}, output)
    pd.DataFrame(history).to_csv(output.with_suffix('.history.csv'), index=False)
    return dict(epochs=len(history), best_validation_loss=best,
                training_seconds=time.perf_counter()-started,
                parameters=sum(p.numel() for p in model.parameters()))

def predict(model, x, cfg, device, mc_passes=0):
    states = {m: m.training for m in model.modules()}
    model.eval()
    if mc_passes:
        # Only dropout is active. BatchNorm statistics remain frozen.
        for module in model.modules():
            if isinstance(module, nn.Dropout):
                module.train()
    loader = DataLoader(Arrays(x, np.zeros(len(x), dtype=int), cfg),
                        batch_size=cfg['batch_size'], shuffle=False, num_workers=0)
    passes = []
    try:
        with torch.no_grad():
            for _ in range(mc_passes or 1):
                passes.append(np.concatenate([torch.softmax(model(a.to(device)), 1).cpu().numpy()
                                               for a, _ in loader]))
    finally:
        for module, state in states.items():
            module.training = state
    return np.stack(passes)

def gradcam(model, image, target_class, device):
    model.eval(); model.zero_grad(set_to_none=True)
    activations = []
    target = model.features[-4]  # Last convolution, before BatchNorm/ReLU/pooling.
    hook = target.register_forward_hook(lambda _, __, output: activations.append(output))
    try:
        x = torch.from_numpy(image[None, None].astype(np.float32)/255.0).to(device)
        logits = model(x)
        activation = activations[0]; activation.retain_grad()
        logits[0, int(target_class)].backward()
        weights = activation.grad.mean(dim=(2, 3), keepdim=True)
        cam = torch.relu((weights*activation).sum(1))[0].detach().cpu().numpy()
        cam = cv2.resize(cam, (image.shape[1], image.shape[0]), interpolation=cv2.INTER_LINEAR)
        if cam.max() > 0:
            cam /= cam.max()
        return cam
    finally:
        hook.remove(); model.zero_grad(set_to_none=True)
