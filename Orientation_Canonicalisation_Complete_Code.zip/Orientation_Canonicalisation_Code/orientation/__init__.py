"""Executable reimplementation of the manuscript's analysis protocol."""
