"""Explicit labels, patient-group splits, duplicate checks and frozen manifests."""
from pathlib import Path
import hashlib
import json
import re
import numpy as np
import pandas as pd
from PIL import Image, ImageOps
from sklearn.model_selection import train_test_split

CLASSES = ['Normal', 'Osteopenia', 'Osteoporosis']
SOURCE = {
    'title': 'Knee X-ray Osteoporosis Database',
    'authors': ['Insha Majeed Wani', 'Sakshi Arora'],
    'doi': '10.17632/fxjm8fb6mw.2',
    'url': 'https://data.mendeley.com/datasets/fxjm8fb6mw/2',
    'version': 2, 'license': 'CC BY 4.0',
}
EXTENSIONS = {'.png', '.jpg', '.jpeg', '.bmp', '.tif', '.tiff'}

def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def pixel_digest(path):
    with Image.open(path) as im:
        a = np.asarray(ImageOps.exif_transpose(im).convert('L'))
    return hashlib.sha256(str(a.shape).encode() + a.tobytes()).hexdigest()

def scan_folder(root, patient_regex=None, allow_image_split=False):
    root = Path(root).resolve()
    if not root.is_dir():
        raise ValueError(f'Dataset folder does not exist: {root}')
    rows = []
    aliases = {'normal': 0, 'osteopenia': 1, 'osteoporosis': 2}
    pattern = re.compile(patient_regex, re.I) if patient_regex else None
    for path in sorted(root.rglob('*')):
        if not path.is_file() or path.suffix.lower() not in EXTENSIONS:
            continue
        found = {aliases[p.lower()] for p in path.relative_to(root).parts[:-1]
                 if p.lower() in aliases}
        if len(found) != 1:
            raise ValueError(f'Cannot assign an unambiguous class to {path}. '
                             'Use class folders or provide a CSV manifest.')
        label = found.pop()
        match = pattern.search(path.stem) if pattern else None
        if pattern and not match:
            raise ValueError(f'Patient expression did not match {path.name}')
        if match:
            patient = match.group(1) if pattern.groups else match.group(0)
            unit = 'patient_group'
        elif allow_image_split:
            patient = 'image:' + str(path.relative_to(root))
            unit = 'image_only_unverified_patient_independence'
        else:
            raise ValueError('Patient IDs are required. Use a CSV with patient_id '
                             'or --patient-regex after checking source filenames. '
                             '--allow-image-split enables explicitly exploratory analysis.')
        row = dict(path=str(path), label=label, patient_id=str(patient), split_unit=unit)
        row['sha256'] = digest(path)
        row['pixel_sha256'] = pixel_digest(path)
        rows.append(row)
    if not rows:
        raise ValueError('No supported images found. DICOM needs an explicit windowing '
                         'and label-joining pipeline; it is not silently converted here.')
    return pd.DataFrame(rows)

def validate_manifest(df, require_splits=True):
    required = {'path', 'label', 'patient_id'} | ({'split'} if require_splits else set())
    if not required <= set(df):
        raise ValueError(f'Missing manifest columns: {sorted(required - set(df))}')
    df = df.copy()
    if df[list(required)].isna().any().any():
        raise ValueError('Manifest has missing paths, labels, patient IDs, or splits.')
    if not df.label.isin([0, 1, 2]).all():
        raise ValueError('Labels must be 0=Normal, 1=Osteopenia, 2=Osteoporosis. '
                         'Kellgren-Lawrence grades cannot be relabelled as bone status.')
    df['label'] = df.label.astype(int)
    df['patient_id'] = df.patient_id.astype(str)
    df['path'] = df.path.map(lambda x: str(Path(x).resolve()))
    if df.path.duplicated().any():
        raise ValueError('A file path occurs more than once.')
    for path in df.path:
        if not Path(path).is_file():
            raise ValueError(f'Missing image: {path}')
    for column, function in [('sha256', digest), ('pixel_sha256', pixel_digest)]:
        actual = df.path.map(function)
        if column in df and (df[column].astype(str) != actual).any():
            raise ValueError(f'Image content changed after manifest creation: {column}')
        df[column] = actual
        if df[column].duplicated().any():
            raise ValueError(f'Exact duplicates detected by {column}. Remove duplicate '
                             'images before splitting; do not manufacture extra samples.')
    if (df.groupby('patient_id').label.nunique() > 1).any():
        raise ValueError('A patient has inconsistent bone-status labels. Resolve metadata '
                         'or use a documented visit-level protocol before analysis.')
    if require_splits:
        if not df.split.isin(['train', 'val', 'test']).all():
            raise ValueError('Splits must be train, val, test.')
        if (df.groupby('patient_id').split.nunique() > 1).any():
            raise ValueError('Patient leakage between splits.')
        for part in ['train', 'val', 'test']:
            if set(df.loc[df.split == part, 'label']) != {0, 1, 2}:
                raise ValueError(f'{part} must contain all three classes.')
    return df

def prepare(root, output, seed=42, patient_regex=None, allow_image_split=False,
            test_fraction=0.15, validation_fraction=0.15):
    if test_fraction <= 0 or validation_fraction <= 0 or test_fraction + validation_fraction >= 1:
        raise ValueError('Train, validation, test fractions must be positive and sum to one.')
    df = validate_manifest(scan_folder(root, patient_regex, allow_image_split), False)
    groups = df.groupby('patient_id', sort=True).label.first()
    train_val, test = train_test_split(groups.index.to_numpy(), stratify=groups.to_numpy(),
                                      test_size=test_fraction, random_state=seed)
    train, val = train_test_split(train_val, stratify=groups.loc[train_val].to_numpy(),
                                 test_size=validation_fraction / (1-test_fraction),
                                 random_state=seed)
    mapping = {**dict.fromkeys(train, 'train'), **dict.fromkeys(val, 'val'),
               **dict.fromkeys(test, 'test')}
    df['split'] = df.patient_id.map(mapping)
    df = validate_manifest(df)
    output = Path(output); output.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(output, index=False)
    audit = dict(source=SOURCE, seed=seed, class_map=dict(enumerate(CLASSES)),
                 counts=pd.crosstab(df.split, df.label).to_dict(),
                 patients=int(df.patient_id.nunique()), images=len(df),
                 split_unit=sorted(df.split_unit.unique().tolist()),
                 paper_counts_are_not_enforced=True,
                 patient_regex=patient_regex,
                 note='The source DOI identifies a compatible dataset, not a verified '
                      'origin for the manuscript working split. Confirm acquisition provenance.')
    output.with_suffix('.audit.json').write_text(json.dumps(audit, indent=2))
    return df

def load_manifest(path):
    path = Path(path).resolve()
    df = pd.read_csv(path, dtype={'patient_id': str})
    df['path'] = df.path.map(lambda p: str((path.parent / p).resolve())
                            if not Path(p).is_absolute() else p)
    return validate_manifest(df)

def make_smoke_dataset(destination):
    """Geometric phantoms for software validation. Not medical/research data."""
    from PIL import ImageDraw
    destination = Path(destination); destination.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(123)
    for k, name in enumerate(CLASSES):
        folder = destination / name; folder.mkdir(exist_ok=True)
        for patient in range(20):
            for view in range(2):
                im = Image.new('L', (160, 160), 20)
                draw = ImageDraw.Draw(im)
                width = 12 + 5*k
                x = 80 + int(rng.integers(-12, 13))
                draw.rectangle((x-width, 15, x+width, 145), fill=95+45*k)
                for j in range(k+1):
                    y = 45+22*j
                    draw.ellipse((x-27, y-7, x+27, y+7), outline=220, width=3)
                a = np.asarray(im).astype(float) + rng.normal(0, 4, (160, 160))
                Image.fromarray(np.uint8(np.clip(a, 0, 255))).save(folder/f'C{k}P{patient:03}_V{view}.png')
    return prepare(destination, destination/'manifest.csv', patient_regex=r'^(C\dP\d+)', seed=42)
