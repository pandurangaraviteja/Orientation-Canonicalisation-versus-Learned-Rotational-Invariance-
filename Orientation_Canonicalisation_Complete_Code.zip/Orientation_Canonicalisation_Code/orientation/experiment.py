from pathlib import Path
import importlib.metadata
import json
import platform
import shutil
import time
import hashlib
import joblib
import numpy as np
import pandas as pd
import torch
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from .data import CLASSES, SOURCE, load_manifest
from .preprocessing import read_image, variant_images, hog_features
from .models import HOGMLP, CompactCNN, seed_everything, train_network, predict
from .metrics import classification_metrics, uncertainty, paired_statistics
from .plots import Figures, FIGURE_NAMES

def json_safe(value):
    if isinstance(value, dict):
        return {str(k):json_safe(v) for k,v in value.items()}
    if isinstance(value, (list,tuple)):
        return [json_safe(v) for v in value]
    if isinstance(value, np.generic):
        return json_safe(value.item())
    if isinstance(value, float) and not np.isfinite(value):
        return None
    return value

def write_json(path, value):
    Path(path).write_text(json.dumps(json_safe(value),indent=2,allow_nan=False))

def select_device(name='auto'):
    if name=='auto':
        name='cuda' if torch.cuda.is_available() else 'cpu'
    if name=='cuda' and not torch.cuda.is_available():
        raise ValueError('CUDA requested, but unavailable. Use --device cpu.')
    return torch.device(name)

def prediction_frame(df,p,diagnostics=None,mc=None):
    result=df[['path','label','patient_id','sha256']].copy()
    for k in range(3):
        result[f'p{k}']=p[:,k]
    result['prediction']=p.argmax(1)
    result['expected_severity']=p@np.arange(3)
    result['correct']=result.prediction==result.label
    if diagnostics is not None:
        result['estimated_ccw_degrees']=[d[0] for d in diagnostics]
        result['hough_line_detected']=[d[1] for d in diagnostics]
    if mc is not None:
        for k in range(3):
            result[f'mc_mean_p{k}']=mc['mean_probabilities'][:,k]
        result['normalized_entropy']=mc['normalized_entropy']
        result['mutual_information']=mc['mutual_information']
    return result

def run(manifest_path, directory, cfg, device_name='auto'):
    df=load_manifest(manifest_path)
    directory=Path(directory)
    if directory.exists() and any(directory.iterdir()):
        raise ValueError('Output directory is not empty. Select a new --out directory '
                         'to preserve the previous experiment.')
    directory.mkdir(parents=True,exist_ok=True)
    models_dir=directory/'models';models_dir.mkdir()
    predictions_dir=directory/'predictions';predictions_dir.mkdir()
    device=select_device(device_name);seed_everything(cfg['seed'],cfg['torch_threads'])
    versions={name:importlib.metadata.version(name) for name in
              ['numpy','pandas','scipy','scikit-learn','scikit-image','opencv-python-headless','matplotlib','Pillow','torch']}
    actual_source=({'title':'Synthetic geometric phantoms for software testing',
                    'doi':None,'medical_data':False} if cfg['synthetic_smoke_test'] else SOURCE)
    metadata=dict(config=cfg,source=actual_source,python=platform.python_version(),versions=versions,
                  device=str(device),class_order=CLASSES,
                  split_counts=pd.crosstab(df.split,df.label).to_dict(),
                  independent_patients=int(df.patient_id.nunique()),
                  manuscript_working_split_not_reconstructed=True,
                  synthetic_smoke_test=cfg['synthetic_smoke_test'],
                  original_counts={'train_plus_val':1966,'test':220},
                  experiment_note='New reimplementation; original manifests, parameters '
                                  'and checkpoints were not supplied. No published metrics are hardcoded.',
                  augmentation_order='Shared preprocessing -> optional canonicalization -> training augmentation',
                  rotation_order='Shared preprocessing -> controlled rotation -> optional canonicalization',
                  calibration='10 (configurable) equal-width top-label confidence bins; empty bins excluded',
                  uncertainty='Deterministic prediction defines correctness; MC mean probabilities define entropy',
                  selection_rule='Lowest weighted validation cross entropy; never test-set model selection')
    write_json(directory/'run_metadata.json',metadata)
    df.to_csv(directory/'manifest.csv',index=False)
    write_json(directory/'dataset_audit.json',dict(source=actual_source,counts=metadata['split_counts'],
               split_unit=sorted(df.split_unit.unique().tolist()) if 'split_unit' in df else ['patient_id_from_manifest'],
               exact_duplicates_checked=True,patient_group_leakage_checked=True,
               near_duplicates_and_augmentation_derivatives_require_provenance_review=True))
    print(f"Loading {len(df)} images; dataset counts are read from the manifest.",flush=True)
    all_images=np.stack([read_image(p,cfg) for p in df.path])
    ix={part:np.flatnonzero(df.split.to_numpy()==part) for part in ['train','val','test']}
    labels=df.label.to_numpy(dtype=int)
    y={part:labels[indices] for part,indices in ix.items()}
    test_df=df.iloc[ix['test']].reset_index(drop=True)
    upright_predictions={};uncertainty_info={};trained={};summaries=[];training_stats={};image_cache={};scalers={}
    pca_coordinates=None;pca_labels=None;baseline_estimates={}
    for variant in ['raw','canon']:
        processed,diagnostics=variant_images(all_images,variant,cfg)
        baseline_estimates[variant]=np.asarray([d[0] for d in diagnostics])[ix['test']]
        image_cache[variant]=processed
        features=hog_features(processed)
        scaler=StandardScaler().fit(features[ix['train']])
        scaled=scaler.transform(features).astype(np.float32)
        scalers[variant]=scaler;joblib.dump(scaler,models_dir/f'scaler_{variant}.joblib')
        pd.DataFrame(dict(path=df.path,split=df.split,variant=variant,
                          estimated_ccw_degrees=[d[0] for d in diagnostics],
                          line_detected=[d[1] for d in diagnostics])).to_csv(
                              directory/f'orientation_{variant}.csv',index=False)
        if variant=='canon':
            pca=PCA(n_components=2,svd_solver='randomized',random_state=cfg['seed']).fit(scaled[ix['train']])
            joblib.dump(pca,models_dir/'pca_train_only.joblib')
            rng=np.random.default_rng(cfg['seed'])
            subset=np.sort(rng.choice(ix['train'],min(len(ix['train']),cfg['pca_max_train_samples']),replace=False))
            pca_coordinates=pca.transform(scaled[subset]);pca_labels=labels[subset]
            df.iloc[subset].to_csv(directory/'pca_train_samples.csv',index=False)
        for kind in ['mlp','rf','cnn']:
            key=f'{kind}_{variant}';print(f'Training {key} ...',flush=True)
            seed_everything(cfg['seed'],cfg['torch_threads'])
            if kind=='rf':
                started=time.perf_counter()
                model=RandomForestClassifier(n_estimators=cfg['rf_trees'],class_weight='balanced',
                                             random_state=cfg['seed'],n_jobs=cfg['rf_jobs'])
                model.fit(scaled[ix['train']],y['train'])
                joblib.dump(model,models_dir/f'{key}.joblib')
                p=model.predict_proba(scaled[ix['test']])
                draws=p[None]
                training_stats[key]=dict(training_seconds=time.perf_counter()-started,
                                         trees=cfg['rf_trees'])
            else:
                inputs=processed if kind=='cnn' else scaled
                model=CompactCNN(cfg) if kind=='cnn' else HOGMLP(scaled.shape[1],cfg)
                training_stats[key]=train_network(model,inputs[ix['train']],y['train'],
                                                  inputs[ix['val']],y['val'],cfg,
                                                  models_dir/f'{key}.pt',device,augment=kind=='cnn')
                p=predict(model,inputs[ix['test']],cfg,device)[0]
                # Re-seeding makes MC evaluation repeatable for a fixed checkpoint.
                seed_everything(cfg['seed']+1000,cfg['torch_threads'])
                draws=predict(model,inputs[ix['test']],cfg,device,mc_passes=cfg['mc_passes'])
            trained[key]=model;upright_predictions[key]=p
            info=uncertainty(draws,p.argmax(1)!=y['test']);uncertainty_info[key]=info
            prediction_frame(test_df,p,[diagnostics[i] for i in ix['test']],info).to_csv(
                predictions_dir/f'{key}_upright.csv',index=False)
            np.savez_compressed(predictions_dir/f'{key}_mc_draws.npz',draws=draws)
            scores=classification_metrics(y['test'],p,cfg['ece_bins'])
            write_json(directory/f'metrics_{key}.json',dict(**scores,
                entropy_error_spearman=info['spearman_rho'],mc_passes=info['passes']))
            summaries.append(dict(model=kind,variant=variant,**{k:v for k,v in scores.items() if k!='per_class'}))
    summary=pd.DataFrame(summaries);summary.to_csv(directory/'metrics_summary.csv',index=False)
    write_json(directory/'training_summary.json',training_stats)
    # Reuse each frozen model and its train-fitted scaler over every angle.
    rotation_rows=[];angle_diagnostics=[]
    test_images=all_images[ix['test']]
    for angle in cfg['angles']:
        print(f'Evaluating rotation {angle:+g} degrees ...',flush=True)
        for variant in ['raw','canon']:
            rotated,diagnostics=variant_images(test_images,variant,cfg,angle)
            features=scalers[variant].transform(hog_features(rotated)).astype(np.float32)
            for kind in ['mlp','rf','cnn']:
                key=f'{kind}_{variant}';model=trained[key]
                if angle==0:
                    p=upright_predictions[key]
                elif kind=='rf':
                    p=model.predict_proba(features)
                else:
                    p=predict(model,rotated if kind=='cnn' else features,cfg,device)[0]
                scores=classification_metrics(y['test'],p,cfg['ece_bins'])
                rotation_rows.append(dict(model=kind,variant=variant,angle=angle,
                    **{k:v for k,v in scores.items() if k!='per_class'},
                    **{f'class_{k}_recall':scores['per_class'][k]['recall'] for k in range(3)}))
                frame=prediction_frame(test_df,p,diagnostics);frame['applied_ccw_degrees']=angle
                frame.to_csv(predictions_dir/f'{key}_angle_{angle:+g}.csv',index=False)
            for j,(estimate,detected) in enumerate(diagnostics):
                angle_diagnostics.append(dict(path=test_df.path.iloc[j],variant=variant,
                    applied_ccw_degrees=angle,estimated_ccw_degrees=estimate,line_detected=detected,
                    # This is relative to the estimator's upright-image estimate,
                    # not an expert-ground-truth anatomical residual.
                    relative_estimator_residual_degrees=(angle - (estimate-
                        float(baseline_estimates[variant][j])))
                    if variant=='canon' else angle))
    rotation=pd.DataFrame(rotation_rows);rotation.to_csv(directory/'rotation_metrics.csv',index=False)
    pd.DataFrame(angle_diagnostics).to_csv(directory/'rotation_estimator_diagnostics.csv',index=False)
    intervals,paired=paired_statistics(y['test'],upright_predictions['mlp_raw'],upright_predictions['mlp_canon'],
                                       test_df.patient_id.to_numpy(),cfg['bootstrap_repetitions'],cfg['seed'])
    intervals.to_csv(directory/'paired_mlp_bootstrap.csv',index=False)
    write_json(directory/'paired_mlp_statistics.json',paired)
    np.savez_compressed(directory/'plot_arrays.npz',y_test=y['test'],pca_coordinates=pca_coordinates,
                        pca_labels=pca_labels,test_canon_images=image_cache['canon'][ix['test']])
    generate_plots(directory,str(device))
    write_checksums(directory)
    print(f'Finished. All {len(FIGURE_NAMES)} figures are in {directory}/figures.',flush=True)

def generate_plots(directory,device_name='auto'):
    directory=Path(directory);metadata=json.loads((directory/'run_metadata.json').read_text());cfg=metadata['config']
    seed_everything(cfg['seed'],cfg['torch_threads']);device=select_device(device_name)
    arrays=np.load(directory/'plot_arrays.npz');y=arrays['y_test']
    summary=pd.read_csv(directory/'metrics_summary.csv');rotation=pd.read_csv(directory/'rotation_metrics.csv')
    predictions={};info={}
    for kind in ['mlp','rf','cnn']:
        for variant in ['raw','canon']:
            key=f'{kind}_{variant}'
            frame=pd.read_csv(directory/'predictions'/f'{key}_upright.csv')
            predictions[key]=frame[['p0','p1','p2']].to_numpy()
            draws=np.load(directory/'predictions'/f'{key}_mc_draws.npz')['draws']
            info[key]=uncertainty(draws,predictions[key].argmax(1)!=y)
    figures=Figures(directory/'figures',cfg)
    figures.architecture();figures.confusion(y,predictions['mlp_raw'],predictions['mlp_canon'])
    figures.perclass(classification_metrics(y,predictions['mlp_canon'],cfg['ece_bins']))
    figures.curves(y,predictions['mlp_canon']);figures.comparison(summary);figures.rotations(rotation)
    figures.calibration(y,predictions['mlp_raw'],predictions['mlp_canon'])
    figures.uncertainty(y,predictions['mlp_canon'],info['mlp_canon'])
    figures.pca(arrays['pca_coordinates'],arrays['pca_labels'])
    model=CompactCNN(cfg).to(device)
    checkpoint=torch.load(directory/'models/cnn_canon.pt',map_location=device,weights_only=True)
    model.load_state_dict(checkpoint['state_dict'])
    ids=pd.read_csv(directory/'predictions/cnn_canon_upright.csv').sha256.tolist()
    figures.gradcam(arrays['test_canon_images'],y,predictions['cnn_canon'],model,device,ids)
    missing=[name for name in FIGURE_NAMES if not (directory/'figures'/f'{name}.png').is_file()]
    if missing:
        raise RuntimeError(f'Missing figures: {missing}')
    write_json(directory/'figure_inventory.json',dict(figures=FIGURE_NAMES,formats=['png','pdf','svg'],
                                                       count=len(FIGURE_NAMES)))

def write_checksums(directory):
    directory=Path(directory);entries=[]
    for p in sorted(directory.rglob('*')):
        if p.is_file() and p.name!='SHA256SUMS.txt':
            h=hashlib.sha256(p.read_bytes()).hexdigest()
            entries.append(f'{h}  {p.relative_to(directory).as_posix()}')
    (directory/'SHA256SUMS.txt').write_text('\n'.join(entries)+'\n')
