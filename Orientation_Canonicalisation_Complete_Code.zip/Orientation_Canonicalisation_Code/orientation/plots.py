"""Every result figure is generated from stored predictions and feature arrays."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from sklearn.metrics import confusion_matrix, roc_curve, auc, precision_recall_curve, average_precision_score
from .data import CLASSES
from .metrics import reliability, uncertainty_quintiles

COLORS = ['#28787c', '#cf7837', '#6374a4']
FIGURE_NAMES = ['fig_arch', 'fig_real_cm_both', 'fig_real_perclass', 'fig_real_roc',
                'fig_real_modelcmp', 'fig_real_compare', 'fig_real_robust',
                'fig_real_robust_perclass', 'fig_cnn_gradcam', 'fig_cnn_robust',
                'fig_real_calib', 'fig_real_uncert', 'fig_real_entropy',
                'fig_real_pca', 'fig_real_pr']

class Figures:
    def __init__(self, directory, cfg):
        self.directory = Path(directory); self.directory.mkdir(parents=True, exist_ok=True)
        self.data = self.directory.parent/'plot_data'; self.data.mkdir(exist_ok=True)
        self.cfg = cfg
        plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,
                             'axes.spines.top':False,'axes.spines.right':False,
                             'savefig.dpi':300,'axes.grid':False})
    def save(self, fig, name):
        footer = ('SYNTHETIC SOFTWARE TEST: these are not radiographs or research results'
                  if self.cfg.get('synthetic_smoke_test') else
                  f"Source: Wani & Arora, Mendeley Data v2 | seed {self.cfg['seed']} | new run")
        fig.tight_layout(rect=(0,0.045,1,1))
        fig.text(0.5,0.008,footer,ha='center',va='bottom',fontsize=6.5)
        for ext in ['png','pdf','svg']:
            fig.savefig(self.directory/f'{name}.{ext}', bbox_inches='tight')
        plt.close(fig)

    def architecture(self):
        fig, ax = plt.subplots(figsize=(12,8)); ax.set_xlim(-8.1,8.1); ax.set_ylim(-11,1)
        ax.axis('off')
        def box(x,y,w,h,text):
            ax.add_patch(Rectangle((x-w/2,y-h/2),w,h,facecolor='white',edgecolor='black',linewidth=.7))
            ax.text(x,y,text,ha='center',va='center',fontsize=8.5)
        def arrow(points):
            x,y=zip(*points)
            if len(points)>2:
                ax.plot(x[:-1],y[:-1],color='black',lw=.7)
            ax.annotate('',xy=points[-1],xytext=points[-2],arrowprops=dict(arrowstyle='->',lw=.7,color='black'))
        box(-5.5,0,3.4,1.0,'Input radiograph')
        size=self.cfg['image_size']
        box(2,0,8.5,1.0,f'Shared preprocessing\nGrayscale; {size} × {size} resizing; CLAHE')
        arrow([(-3.8,0),(-2.25,0)])
        box(-5.4,-2,3.8,1.35,'Raw control\nBypass orientation correction')
        box(-.3,-2,4.1,1.35,'Orientation estimation\nCanny edges → Hough line\nEstimated in-plane angle θ')
        box(5.3,-2,4,1.35,'SO(2) correction\nRotate by −θ\nBilinear interpolation; zero padding')
        arrow([(2,-.5),(2,-.95),(-5.4,-.95),(-5.4,-1.325)])
        arrow([(2,-.95),(-.3,-.95),(-.3,-1.325)])
        arrow([(1.75,-2),(3.3,-2)])
        box(0,-3.7,15,1,'Matched recognition comparison\nOne input variant per run; same held-out split')
        arrow([(-5.4,-2.675),(-5.4,-3.2)]); arrow([(5.3,-2.675),(5.3,-3.2)])
        hidden=self.cfg['mlp_hidden'];trees=self.cfg['rf_trees']
        box(-4,-5.7,7,1.8,f'HOG-based recognizers\n9 bins; 16 × 16 cells; 2 × 2 blocks\nL2-Hys; train-fitted z-score\nMLP {hidden[0]} → {hidden[1]} with dropout or RF {trees} trees')
        box(4,-5.7,7,1.8,'Compact CNN recognizer\n3 convolutional blocks; BN, ReLU, pooling\nGlobal average pooling; dropout; Softmax\nRotation / flip training augmentation')
        arrow([(0,-4.2),(0,-4.5),(-4,-4.5),(-4,-4.8)])
        arrow([(0,-4.5),(4,-4.5),(4,-4.8)])
        box(0,-7.75,13,1.1,'Class probabilities, evaluated separately\np₀ Normal; p₁ Osteopenia; p₂ Osteoporosis\nPredictions are not fused')
        arrow([(-4,-6.6),(-4,-7.2)]);arrow([(4,-6.6),(4,-7.2)])
        box(-4,-9.8,7,1.4,'Ordinal prediction\nClass = argmax pₖ\nExpected severity = Σ k pₖ')
        box(4,-9.8,7,1.4,'Uncertainty analysis\nPredictive entropy; MC dropout where applicable\nExploratory clinician review flag')
        arrow([(0,-8.3),(0,-8.7),(-4,-8.7),(-4,-9.1)])
        arrow([(0,-8.7),(4,-8.7),(4,-9.1)])
        self.save(fig,'fig_arch')

    def confusion(self,y,raw,canon):
        fig,axes=plt.subplots(1,2,figsize=(9,3.7))
        for ax,p,title in zip(axes,[raw,canon],['Raw MLP','Canonicalized MLP']):
            counts=confusion_matrix(y,p.argmax(1),labels=[0,1,2])
            percentages=counts/np.maximum(counts.sum(1,keepdims=True),1)
            ax.imshow(percentages,vmin=0,vmax=1,cmap='Greens')
            for i in range(3):
                for j in range(3):
                    ax.text(j,i,f'{counts[i,j]}\n{100*percentages[i,j]:.1f}%',ha='center',va='center',
                            color='white' if percentages[i,j]>.6 else 'black',fontsize=9)
            ax.set(xticks=range(3),yticks=range(3),xticklabels=CLASSES,yticklabels=CLASSES,
                   xlabel='Predicted class',ylabel='Reference class',title=title)
            ax.tick_params(axis='x',rotation=25)
            pd.DataFrame(counts,index=CLASSES,columns=CLASSES).to_csv(self.data/f'cm_{title.split()[0].lower()}.csv')
        self.save(fig,'fig_real_cm_both')

    def perclass(self,metrics):
        df=pd.DataFrame(metrics['per_class']);df.to_csv(self.data/'per_class.csv',index=False)
        fig,ax=plt.subplots(figsize=(6.6,4)); x=np.arange(3)
        for j,key in enumerate(['precision','recall','f1']):
            ax.bar(x+(j-1)*.24,df[key],.24,label=key.capitalize(),color=COLORS[j])
        ax.set(xticks=x,xticklabels=CLASSES,ylim=(0,1.05),ylabel='Score',title='Canonicalized MLP: per-class performance')
        ax.legend(ncol=3,loc='upper center',fontsize=8)
        self.save(fig,'fig_real_perclass')

    def curves(self,y,p):
        for mode,name in [('roc','fig_real_roc'),('pr','fig_real_pr')]:
            fig,ax=plt.subplots(figsize=(5.4,4.4))
            for k,color in enumerate(COLORS):
                binary=(y==k).astype(int)
                if len(np.unique(binary))<2:
                    continue
                if mode=='roc':
                    a,b,thresholds=roc_curve(binary,p[:,k]);score=auc(a,b)
                    ax.plot(a,b,color=color,label=f'{CLASSES[k]} (AUC {score:.3f})')
                    df=pd.DataFrame(dict(false_positive_rate=a,true_positive_rate=b,threshold=thresholds))
                else:
                    precision,recall,thresholds=precision_recall_curve(binary,p[:,k]);score=average_precision_score(binary,p[:,k])
                    ax.plot(recall,precision,color=color,label=f'{CLASSES[k]} (AP {score:.3f})')
                    df=pd.DataFrame(dict(recall=recall,precision=precision,threshold=np.r_[thresholds,np.nan]))
                df.to_csv(self.data/f'{mode}_{k}.csv',index=False)
            if mode=='roc':
                ax.plot([0,1],[0,1],'k--',lw=.7)
                ax.set(xlabel='False positive rate',ylabel='True positive rate',title='One-vs-rest ROC: canonicalized MLP')
            else:
                ax.set(xlabel='Recall',ylabel='Precision',title='One-vs-rest precision–recall: canonicalized MLP')
            ax.set_xlim(0,1);ax.set_ylim(0,1.02);ax.legend(fontsize=8)
            self.save(fig,name)

    def comparison(self,summary):
        selected=summary[summary.model.isin(['mlp','rf'])].copy()
        selected.to_csv(self.data/'model_comparison.csv',index=False)
        fig,ax=plt.subplots(figsize=(7,4));x=np.arange(len(selected))
        for j,key in enumerate(['accuracy','macro_f1','qwk']):
            ax.bar(x+(j-1)*.24,selected[key],.24,label=key,color=COLORS[j])
        ax.set(xticks=x,xticklabels=[f'{r.model.upper()}\n{r.variant}' for r in selected.itertuples()],
               ylim=(-.1,1.05),ylabel='Score',title='Held-out model comparison');ax.legend(fontsize=8,ncol=3)
        self.save(fig,'fig_real_modelcmp')
        selected=summary[summary.model=='mlp'];fig,ax=plt.subplots(figsize=(5.5,4));x=np.arange(3)
        for j,(variant,color) in enumerate(zip(['raw','canon'],COLORS)):
            row=selected[selected.variant==variant].iloc[0]
            ax.bar(x+(j-.5)*.32,[row.accuracy,row.macro_f1,row.qwk],.32,label=variant,color=color)
        ax.set(xticks=x,xticklabels=['Accuracy','Macro-F1','QWK'],ylim=(-.1,1.05),ylabel='Score',
               title='Raw vs canonicalized MLP');ax.legend(fontsize=8)
        self.save(fig,'fig_real_compare')

    def rotations(self,rotation):
        rotation.to_csv(self.data/'rotation_curves.csv',index=False)
        for model,name in [('mlp','fig_real_robust'),('cnn','fig_cnn_robust')]:
            fig,ax=plt.subplots(figsize=(5.7,4));curves=[]
            for variant,color in zip(['raw','canon'],COLORS):
                df=rotation[(rotation.model==model)&(rotation.variant==variant)].sort_values('angle')
                ax.plot(df.angle,df.accuracy,'o-',label=variant,color=color);curves.append(df)
            if model=='mlp':
                ax.fill_between(curves[0].angle,curves[0].accuracy,curves[1].accuracy,color=COLORS[0],alpha=.13,
                                label='Numerical difference, not a confidence interval')
            ax.set(xlabel='Applied CCW rotation (degrees)',ylabel='Accuracy',ylim=(0,1.02),
                   title=f'{model.upper()} rotation robustness');ax.legend(fontsize=7)
            self.save(fig,name)
        fig,axes=plt.subplots(1,2,figsize=(9,4),sharey=True)
        for ax,variant in zip(axes,['raw','canon']):
            df=rotation[(rotation.model=='mlp')&(rotation.variant==variant)].sort_values('angle')
            for k,color in enumerate(COLORS):
                ax.plot(df.angle,df[f'class_{k}_recall'],'o-',label=CLASSES[k],color=color)
            ax.set(xlabel='Applied CCW rotation (degrees)',title=f'MLP: {variant}',ylim=(0,1.02))
            ax.legend(fontsize=7)
        axes[0].set_ylabel('Per-class recall (within-class accuracy)')
        self.save(fig,'fig_real_robust_perclass')

    def calibration(self,y,raw,canon):
        fig,ax=plt.subplots(figsize=(5.4,4.4));ax.plot([0,1],[0,1],'k--',lw=.8,label='Perfect calibration')
        for variant,p,color in zip(['raw','canon'],[raw,canon],COLORS):
            df=reliability(y,p,self.cfg['ece_bins']);df.to_csv(self.data/f'reliability_{variant}.csv',index=False)
            occupied=df[df['count']>0]
            ece=((occupied['count']/len(y))*abs(occupied.accuracy-occupied.mean_confidence)).sum()
            ax.plot(occupied.mean_confidence,occupied.accuracy,'o-',label=f'{variant} (ECE {ece:.3f})',color=color)
        ax.set(xlabel='Mean confidence in occupied bin',ylabel='Empirical accuracy',xlim=(0,1),ylim=(0,1.02),
               title='MLP reliability diagram');ax.legend(fontsize=8)
        self.save(fig,'fig_real_calib')

    def uncertainty(self,y,deterministic_p,info):
        errors=(deterministic_p.argmax(1)!=y).astype(int);u=info['normalized_entropy']
        quintiles=uncertainty_quintiles(u,errors);quintiles.to_csv(self.data/'uncertainty_quintiles.csv',index=False)
        fig,ax=plt.subplots(figsize=(5.6,4));ax.bar(quintiles.quintile,quintiles.error_rate,color=COLORS[0])
        for row in quintiles.itertuples():
            ax.text(row.quintile,row.error_rate+.02,f'n={row.n}',ha='center',fontsize=8)
        ax.set(xticks=range(1,6),xlabel='Predictive entropy quintile (low to high)',ylabel='Prediction error rate',
               ylim=(0,1.12),title='MLP error rate by uncertainty quintile');self.save(fig,'fig_real_uncert')
        fig,ax=plt.subplots(figsize=(5.7,4));bins=np.linspace(0,1,21)
        for flag,label,color in [(0,'Correct',COLORS[0]),(1,'Incorrect',COLORS[1])]:
            ax.hist(u[errors==flag],bins=bins,alpha=.65,label=f'{label} (n={(errors==flag).sum()})',color=color)
        rho=info['spearman_rho'];text=f'{rho:.3f}' if np.isfinite(rho) else 'undefined (constant errors/entropy)'
        ax.set(xlabel='Normalized predictive entropy',ylabel='Number of test images',
               title=f'Entropy and prediction correctness\nSpearman ρ = {text}');ax.legend(fontsize=8)
        pd.DataFrame(dict(error=errors,normalized_entropy=u)).to_csv(self.data/'entropy_errors.csv',index=False)
        self.save(fig,'fig_real_entropy')

    def pca(self,coordinates,labels):
        pd.DataFrame(dict(pc1=coordinates[:,0],pc2=coordinates[:,1],label=labels)).to_csv(self.data/'pca_train.csv',index=False)
        fig,ax=plt.subplots(figsize=(5.7,4.4))
        for k,color in enumerate(COLORS):
            mask=labels==k;ax.scatter(*coordinates[mask].T,s=10,alpha=.6,label=CLASSES[k],color=color)
        ax.set(xlabel='PC1',ylabel='PC2',title='Canonicalized HOG: training data only');ax.legend(fontsize=8)
        self.save(fig,'fig_real_pca')

    def gradcam(self,images,y,p,model,device,sample_ids):
        from .models import gradcam
        fig,axes=plt.subplots(2,3,figsize=(8.4,5.7));selection=[]
        for k in range(3):
            choices=np.flatnonzero((y==k)&(p.argmax(1)==y))
            for ax in axes[:,k]:
                ax.axis('off')
            if not len(choices):
                axes[0,k].text(.5,.5,f'{CLASSES[k]}\nNo correctly classified test image',ha='center',va='center',transform=axes[0,k].transAxes)
                selection.append(dict(label=k,sample_id=None,reason='no_correct_example'))
                continue
            index=choices[np.argmax(p[choices,k])];image=images[index];heat=gradcam(model,image,k,device)
            axes[0,k].imshow(image,cmap='gray',vmin=0,vmax=255)
            axes[0,k].set_title(f'{CLASSES[k]}\np={p[index,k]:.3f}',fontsize=9)
            axes[1,k].imshow(image,cmap='gray',vmin=0,vmax=255)
            if heat.max()>0:
                axes[1,k].imshow(heat,cmap='jet',vmin=0,vmax=1,alpha=.45)
            else:
                axes[1,k].text(.5,.05,'Zero positive Grad-CAM response',ha='center',fontsize=7,transform=axes[1,k].transAxes,color='white')
            np.save(self.data/f'gradcam_class_{k}.npy',heat)
            selection.append(dict(label=k,sample_id=sample_ids[index],test_index=int(index),
                                  selected_by='highest confidence among correctly classified examples'))
        pd.DataFrame(selection).to_csv(self.data/'gradcam_selection.csv',index=False)
        fig.suptitle('CNN Grad-CAM: selected test examples (descriptive explanations)',fontsize=10)
        self.save(fig,'fig_cnn_gradcam')
