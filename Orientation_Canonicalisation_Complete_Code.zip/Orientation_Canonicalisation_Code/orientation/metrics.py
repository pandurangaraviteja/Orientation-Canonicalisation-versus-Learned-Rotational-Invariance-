import numpy as np
import pandas as pd
from scipy.stats import spearmanr, binomtest
from sklearn.metrics import (accuracy_score, f1_score, cohen_kappa_score,
                             precision_recall_fscore_support)

def check_probabilities(probabilities, n=None):
    p = np.asarray(probabilities, dtype=float)
    if p.ndim != 2 or p.shape[1] != 3 or (n is not None and len(p) != n):
        raise ValueError('Expected probabilities with shape [N,3].')
    if not np.isfinite(p).all() or (p < -1e-7).any() or (p > 1+1e-7).any():
        raise ValueError('Probabilities must be finite and in [0,1].')
    if not np.allclose(p.sum(1), 1, atol=1e-5):
        raise ValueError('Class probabilities must sum to one.')
    return p

def reliability(y, p, bins=10):
    p = check_probabilities(p, len(y)); conf = p.max(1); correct = p.argmax(1) == y
    edges = np.linspace(0, 1, bins+1)
    membership = np.minimum(np.searchsorted(edges, conf, side='right')-1, bins-1)
    rows = []
    for b in range(bins):
        mask = membership == b
        rows.append(dict(bin=b, lower=edges[b], upper=edges[b+1], count=int(mask.sum()),
                         mean_confidence=float(conf[mask].mean()) if mask.any() else np.nan,
                         accuracy=float(correct[mask].mean()) if mask.any() else np.nan))
    return pd.DataFrame(rows)

def classification_metrics(y, p, bins=10):
    p = check_probabilities(p, len(y)); pred = p.argmax(1)
    rel = reliability(y, p, bins)
    occupied = rel[rel['count'] > 0]
    ece = ((occupied['count']/len(y)) *
           np.abs(occupied.accuracy-occupied.mean_confidence)).sum()
    precision, recall, f1, support = precision_recall_fscore_support(
        y, pred, labels=[0, 1, 2], zero_division=0)
    return dict(accuracy=float(accuracy_score(y, pred)),
                macro_f1=float(f1_score(y, pred, labels=[0,1,2], average='macro', zero_division=0)),
                qwk=float(cohen_kappa_score(y, pred, labels=[0,1,2], weights='quadratic')),
                ece=float(ece), mae=float(np.mean(np.abs(pred-y))),
                rmse=float(np.sqrt(np.mean((pred-y)**2))),
                severe_error_rate=float(np.mean(np.abs(pred-y) >= 2)),
                per_class=[dict(label=k, precision=float(precision[k]), recall=float(recall[k]),
                                f1=float(f1[k]), support=int(support[k])) for k in range(3)])

def entropy(p):
    p = np.asarray(p, dtype=float)
    return -(p*np.log(np.clip(p, 1e-12, 1))).sum(axis=-1)

def uncertainty(draws, errors):
    draws = np.asarray(draws)
    mean = draws.mean(0)
    check_probabilities(mean, len(errors))
    u = entropy(mean)/np.log(3)
    if np.unique(errors).size < 2 or np.ptp(u) < 1e-12:
        rho, pvalue = np.nan, np.nan
    else:
        rho, pvalue = spearmanr(u, np.asarray(errors, dtype=int))
    mi = entropy(mean)-entropy(draws).mean(0) if len(draws)>1 else np.full(len(mean), np.nan)
    return dict(mean_probabilities=mean, normalized_entropy=u,
                mutual_information=np.maximum(mi, 0),
                spearman_rho=float(rho), spearman_pvalue=float(pvalue), passes=len(draws))

def uncertainty_quintiles(u, errors):
    rows = []
    for i, indices in enumerate(np.array_split(np.argsort(u, kind='stable'), 5)):
        rows.append(dict(quintile=i+1, n=len(indices),
                         mean_entropy=float(np.mean(u[indices])) if len(indices) else np.nan,
                         error_rate=float(np.mean(errors[indices])) if len(indices) else np.nan))
    return pd.DataFrame(rows)

def paired_statistics(y, raw, canon, patient_ids, repetitions=1000, seed=42):
    """Patient-cluster bootstrap retains raw/canonicalized pairing."""
    ids = np.asarray(patient_ids, dtype=str); groups = np.unique(ids)
    indices = {g: np.flatnonzero(ids==g) for g in groups}
    rng = np.random.default_rng(seed); distributions = {k: [] for k in ['accuracy','macro_f1','qwk']}
    def values(yy, pp):
        return dict(accuracy=accuracy_score(yy, pp),
                    macro_f1=f1_score(yy, pp, labels=[0,1,2], average='macro', zero_division=0),
                    qwk=cohen_kappa_score(yy, pp, labels=[0,1,2], weights='quadratic'))
    a, b = raw.argmax(1), canon.argmax(1)
    observed_a, observed_b = values(y,a), values(y,b)
    for _ in range(repetitions):
        ix = np.concatenate([indices[g] for g in rng.choice(groups, len(groups), replace=True)])
        va, vb = values(y[ix], a[ix]), values(y[ix], b[ix])
        for key in distributions:
            delta = vb[key]-va[key]
            if np.isfinite(delta):
                distributions[key].append(delta)
    rows = []
    for key, samples in distributions.items():
        lo, hi = np.quantile(samples,[0.025,0.975]) if samples else (np.nan,np.nan)
        rows.append(dict(metric=key, canonicalized_minus_raw=observed_b[key]-observed_a[key],
                         lower_95=lo, upper_95=hi, valid_bootstrap_repetitions=len(samples),
                         unit='patient_cluster', method='paired percentile bootstrap'))
    raw_only = int(((a==y)&(b!=y)).sum()); canon_only = int(((a!=y)&(b==y)).sum())
    independent = len(groups)==len(y)
    discordant = raw_only+canon_only
    mcnemar = dict(raw_only_correct=raw_only, canon_only_correct=canon_only,
                   exact_pvalue=(float(binomtest(raw_only,discordant,0.5).pvalue)
                                 if discordant else 1.0) if independent else None,
                   note='Exact image-level McNemar test only when one image per patient. '
                        'No independent-image test is claimed for repeated patient views.')
    return pd.DataFrame(rows), mcnemar
