"""Scientific invariants that catch leakage, sign errors and inference drift."""
import json
import tempfile
import unittest
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from PIL import Image
from orientation.data import validate_manifest, prepare, make_smoke_dataset
from orientation.preprocessing import rotate, canonicalize, estimate_orientation, hog_features
from orientation.models import CompactCNN, predict, seed_everything, gradcam
from orientation.metrics import reliability, classification_metrics, uncertainty, uncertainty_quintiles

ROOT=Path(__file__).resolve().parents[1]
CFG=json.loads((ROOT/'config.json').read_text())

class ProtocolTests(unittest.TestCase):
    def test_rotation_sign_and_residual(self):
        im=np.zeros((128,128),dtype=np.uint8);im[10:118,58:70]=255
        for angle in [-15,-10,0,10,15]:
            observed=rotate(im,angle)
            estimate,found=estimate_orientation(observed,CFG)
            self.assertTrue(found)
            self.assertLess(abs(estimate-angle),2)
            corrected,_,_=canonicalize(observed,CFG)
            residual,found=estimate_orientation(corrected,CFG)
            self.assertTrue(found)
            self.assertLess(abs(residual),2)

    def test_hog_dimension_matches_paper(self):
        self.assertEqual(hog_features(np.zeros((2,128,128),dtype=np.uint8)).shape,(2,1764))

    def test_perfect_predictions_have_zero_ece(self):
        y=np.array([0,1,2]);p=np.eye(3)
        metrics=classification_metrics(y,p)
        self.assertEqual(metrics['accuracy'],1)
        self.assertEqual(metrics['qwk'],1)
        self.assertEqual(metrics['ece'],0)
        df=reliability(y,p)
        self.assertEqual(df['count'].sum(),3)
        self.assertEqual(df.iloc[-1]['count'],3)

    def test_constant_uncertainty_is_not_reported_as_a_correlation(self):
        info=uncertainty(np.full((5,4,3),1/3),np.array([0,1,0,1]))
        self.assertTrue(np.isnan(info['spearman_rho']))
        self.assertTrue(np.allclose(info['normalized_entropy'],1))
        self.assertTrue(np.allclose(info['mutual_information'],0))

    def test_quintiles_partition_samples_even_with_ties(self):
        df=uncertainty_quintiles(np.zeros(12),np.arange(12)%2)
        self.assertEqual(df.n.sum(),12)
        self.assertEqual(len(df),5)

    def test_mc_dropout_freezes_batchnorm_and_restores_states(self):
        seed_everything(42)
        model=CompactCNN(CFG);model.eval()
        before={k:v.clone() for k,v in model.state_dict().items() if 'running_' in k or 'num_batches_tracked' in k}
        x=np.random.default_rng(1).integers(0,256,(4,128,128),dtype=np.uint8)
        states=[m.training for m in model.modules()]
        draws=predict(model,x,CFG,torch.device('cpu'),mc_passes=4)
        self.assertEqual(draws.shape,(4,4,3))
        self.assertTrue(np.allclose(draws.sum(2),1,atol=1e-6))
        self.assertGreater(float(np.std(draws,axis=0).max()),0)
        self.assertEqual(states,[m.training for m in model.modules()])
        for k,v in before.items():
            self.assertTrue(torch.equal(v,model.state_dict()[k]))

    def test_missing_patient_ids_are_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);folder=root/'Normal';folder.mkdir()
            Image.fromarray(np.ones((32,32),dtype=np.uint8)).save(folder/'image.png')
            with self.assertRaisesRegex(ValueError,'Patient IDs are required'):
                prepare(root,root/'manifest.csv')

    def test_gradcam_is_computed_for_each_target_class(self):
        seed_everything(42)
        model=CompactCNN(CFG)
        image=np.random.default_rng(2).integers(0,256,(128,128),dtype=np.uint8)
        for target in [0,1,2]:
            heat=gradcam(model,image,target,torch.device('cpu'))
            self.assertEqual(heat.shape,image.shape)
            self.assertTrue(np.isfinite(heat).all())
            self.assertGreaterEqual(heat.min(),0)
            self.assertLessEqual(heat.max(),1)

    def test_patient_groups_stay_together_and_leakage_is_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            df=make_smoke_dataset(d)
            self.assertTrue((df.groupby('patient_id').split.nunique()==1).all())
            bad=df.copy();group=bad.patient_id.iloc[0];indices=bad.index[bad.patient_id==group]
            original=bad.loc[indices[0],'split'];replacement='test' if original!='test' else 'train'
            bad.loc[indices[0],'split']=replacement
            with self.assertRaisesRegex(ValueError,'Patient leakage'):
                validate_manifest(bad)

    def test_exact_pixel_duplicates_are_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            df=make_smoke_dataset(d)
            path=Path(d)/'duplicate.png';path.write_bytes(Path(df.path.iloc[0]).read_bytes())
            row=df.iloc[[0]].copy();row['path']=str(path)
            with self.assertRaisesRegex(ValueError,'Exact duplicates'):
                validate_manifest(pd.concat([df,row],ignore_index=True))

if __name__=='__main__':
    unittest.main()
