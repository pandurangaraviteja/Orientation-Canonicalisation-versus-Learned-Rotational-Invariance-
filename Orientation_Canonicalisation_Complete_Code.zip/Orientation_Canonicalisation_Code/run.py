#!/usr/bin/env python3
"""Prepare -> train/evaluate -> regenerate all manuscript figures."""
import argparse
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='command',required=True)
    prep=sub.add_parser('prepare',help='Create a patient-group manifest from three class folders.')
    prep.add_argument('--data',required=True);prep.add_argument('--manifest',required=True)
    prep.add_argument('--patient-regex');prep.add_argument('--allow-image-split',action='store_true')
    prep.add_argument('--seed',type=int,default=42)
    prep.add_argument('--test-fraction',type=float,default=.15);prep.add_argument('--val-fraction',type=float,default=.15)
    train=sub.add_parser('run',help='Train all six model/input combinations and generate every figure.')
    train.add_argument('--manifest',required=True);train.add_argument('--out',required=True)
    train.add_argument('--config',default=str(ROOT/'config.json'));train.add_argument('--device',choices=['auto','cpu','cuda'],default='auto')
    train.add_argument('--epochs',type=int);train.add_argument('--seed',type=int)
    plots=sub.add_parser('plots',help='Regenerate figures from a finished run without retraining.')
    plots.add_argument('--run',required=True);plots.add_argument('--device',choices=['auto','cpu','cuda'],default='auto')
    smoke=sub.add_parser('smoke',help='Software-only synthetic phantom test, not research results.')
    smoke.add_argument('--out',required=True);smoke.add_argument('--epochs',type=int,default=3)
    args=parser.parse_args()
    if args.command=='prepare':
        from orientation.data import prepare
        df=prepare(args.data,args.manifest,args.seed,args.patient_regex,args.allow_image_split,
                   args.test_fraction,args.val_fraction)
        print(df.groupby(['split','label']).size().to_string())
        print('Manifest written. Confirm group identities and provenance before the experiment.')
    elif args.command=='run':
        from orientation.experiment import run
        cfg=json.loads(Path(args.config).read_text())
        if args.epochs is not None:
            cfg['epochs']=args.epochs
        if args.seed is not None:
            cfg['seed']=args.seed
        if cfg['epochs']<1 or cfg['mc_passes']<2 or cfg['bootstrap_repetitions']<1:
            raise ValueError('epochs and bootstrap repetitions must be positive; MC passes >=2.')
        run(args.manifest,args.out,cfg,args.device)
    elif args.command=='plots':
        from orientation.experiment import generate_plots,write_checksums
        generate_plots(args.run,args.device);write_checksums(args.run)
    else:
        from orientation.data import make_smoke_dataset
        from orientation.experiment import run
        output=Path(args.out)
        if output.exists() and any(output.iterdir()):
            raise ValueError('Choose an empty smoke output directory.')
        make_smoke_dataset(output/'synthetic_phantoms')
        cfg=json.loads((ROOT/'config.json').read_text())
        cfg.update(synthetic_smoke_test=True,epochs=args.epochs,patience=args.epochs,
                   bootstrap_repetitions=50,rf_trees=20,mc_passes=5)
        run(output/'synthetic_phantoms/manifest.csv',output/'experiment',cfg,'cpu')

if __name__=='__main__':
    main()
